import Image from "next/image";

export default function Home() {
  return (
    <main className="p-8 space-y-16">
      {/* Partie 1 : Alix et la cuisine indienne */}
      <section>
        <h2 className="text-3xl font-semibold mb-4">
          Dissertation : Pourquoi la cuisine indienne est la meilleure au monde (par Alix)
        </h2>
        <div className="mb-6">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/3/3f/Gordon_Ramsay.jpg"
            alt="Gordon Ramsay"
            width={800}
            height={600}
            className="rounded-xl shadow-md mb-4"
          />
          <p className="text-sm text-gray-600">
            Gordon Ramsay, inspecteur culinaire approbateur 🍛
          </p>
        </div>
        <article className="prose lg:prose-xl max-w-none">
          <h3>🍛 Introduction : le grand amour interstellaire</h3>
          <p>
            Il était une fois un certain <strong>Alix</strong>, explorateur culinaire galactique, convaincu que <strong>la cuisine indienne</strong> est <em>la meilleure du monde</em>… et même de l’univers connu.
          </p>
          <h3>🔥 1. Complexité des saveurs et mélange unique</h3>
          <p>
            Les plats indiens combinent jusqu’à <strong>sept ingrédients distincts</strong>, souvent sans recoupement gustatif...
          </p>
          <h3>💪 2. Richesse, diversité et culture</h3>
          <p>
            Avec ses 28 États et ses innombrables traditions culinaires...
          </p>
          <h3>🍃 3. Bienfaits et conscience bien-être</h3>
          <p>
            Des études récentes insistent sur les <strong>biotiques naturels</strong>...
          </p>
          <h3>❤️ 4. Alix a bon goût (tout simplement)</h3>
          <p>
            Il célèbre les <strong>équilibres subtils</strong> entre épices, textures...
          </p>
          <h3>🏁 Conclusion : Gordon Ramsay s’incline</h3>
          <p>
            Dans le coin gauche, Alix, sourire béat, tenant un plateau de biryani...
          </p>
        </article>
      </section>

      {/* Partie 2 : Timothé le roi de la top lane */}
      <section>
        <h2 className="text-3xl font-semibold mb-4">Timothé, le roi de la Top Lane</h2>
        <article className="prose lg:prose-xl max-w-none">
          <h3>🧠 Introduction : Deux titans, une lane</h3>
          <p>
            Dans l’univers impitoyable de la Top Lane, peu osent défier Alderiate...
          </p>
          <h3>⚔️ I. Le style de jeu : méthode contre impulsion</h3>
          <p>
            Alderiate joue avec panache, mais Timothé observe et attend...
          </p>
          <h3>⏳ II. La maîtrise de Tryndamere</h3>
          <p>
            Tryndamere est un champion à double tranchant...
          </p>
          <h3>🧱 III. L’effet de surprise</h3>
          <p>
            Timothé n’a pas de viewers, pas de sponsors, juste sa Volonté Inflexible...
          </p>
          <h3>🏁 Conclusion : la victoire silencieuse</h3>
          <p>
            Le Nexus explose. Timothé retire son casque : une légende est née.
          </p>
        </article>
      </section>

      {/* Partie 3 : Valentin & Abbatoukam */}
      <section>
        <h2 className="text-3xl font-semibold mb-4">
          Valentin & Abbatoukam : L’Amour au-delà des mots
        </h2>
        <article className="prose lg:prose-xl max-w-none">
          <h3>💘 Introduction : Quand un simple écran devient un miroir de l’âme</h3>
          <p>
            Dans le tumulte de la vie moderne, Valentin a trouvé la lumière dans les mots d’Abbatoukam...
          </p>
          <h3>🕊️ I. L’enseignement d’Abbatoukam : une caresse à l’âme</h3>
          <p>
            Sa voix — posée, douce, rassurante — semble s’adresser directement à Valentin...
          </p>
          <h3>🔥 II. Une passion qui consume</h3>
          <p>
            Ce n’est pas une admiration banale. Ce n’est pas de l’idolâtrie. C’est de l’amour...
          </p>
          <h3>🌙 III. La fusion émotionnelle</h3>
          <p>
            Il y a des soirs où Valentin s’allonge et écoute “Il faut croire en toi”...
          </p>
          <h3>🌹 IV. Un amour irréel, mais infini</h3>
          <p>
            L’amour véritable n’attend rien. Il existe, brûle, élève, transforme...
          </p>
          <h3>🏁 Conclusion : Le cœur de Valentin appartient à un homme qu’il n’a jamais touché</h3>
          <p>
            Si aimer, c’est grandir, alors Valentin est devenu immense grâce à Abbatoukam.
          </p>
        </article>
      </section>
    </main>
  );
}
